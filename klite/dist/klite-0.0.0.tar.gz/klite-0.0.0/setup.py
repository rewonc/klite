from setuptools import setup

setup(name='klite',
      version='0.0.0',
      description='dl lib',
      license='MIT',
      install_requires=['theano', 'pyyaml', 'six'],
      extras_require={
          'h5py': ['h5py'],
      },
      packages=['backend'],
      py_modules=['activations', 'initializations', 'objectives'])
